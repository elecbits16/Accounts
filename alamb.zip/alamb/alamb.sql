-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2018 at 01:23 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alamb`
--

-- --------------------------------------------------------

--
-- Table structure for table `form_details`
--

CREATE TABLE `form_details` (
  `dob` varchar(256) DEFAULT NULL,
  `gender` varchar(256) DEFAULT NULL,
  `nam` varchar(256) DEFAULT NULL,
  `c_nam` varchar(256) DEFAULT NULL,
  `c_email` varchar(256) DEFAULT NULL,
  `p_email` varchar(256) DEFAULT NULL,
  `amount` varchar(256) DEFAULT NULL,
  `amount_actual` varchar(256) DEFAULT NULL,
  `emp_id` varchar(256) DEFAULT NULL,
  `d_nam` varchar(256) DEFAULT NULL,
  `loc` varchar(256) DEFAULT NULL,
  `phn` varchar(256) DEFAULT NULL,
  `ack` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_details`
--

INSERT INTO `form_details` (`dob`, `gender`, `nam`, `c_nam`, `c_email`, `p_email`, `amount`, `amount_actual`, `emp_id`, `d_nam`, `loc`, `phn`, `ack`) VALUES
('2018-03-16	        ', 'male	    ', 'jkch	        ', 'sda	        ', 'KASJ@akans.com	    ', 'LZJCN@sd.com	    ', '500	    ', '	', '224244	    ', 'AC	        ', 'wdasd	        ', '1133456677	        ', 'Please mail my tax Receipt 	        ');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
