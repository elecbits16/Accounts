<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<title>Alamb</title>
</head>
<body>

<br>
<br>

<div class="container">
<div class="col-lg-12">

<form method="post" action="">

	<div class="form-group row">
  <label for="example-date-input" class="col-2 col-form-label">Date</label>
  <div class="col-10">
    <input class="form-control" name="dob" type="date"  id="example-date-input">
  </div>
</div>

	<div class="form-group row">

  <label for="example-date-input" class="col-2 col-form-label">Gender</label>

   <div class="col-4">
  <select class="custom-select mb-2 mr-sm-2 mb-sm-0" id="inlineFormCustomSelect" name="gender">
       <option value="male">Male</option>
    <option value="gender">Female</option>
   
  </select>
</div>
</div>


	<div class="form-group row">
  <label for="example-date-input" class="col-2 col-form-label">Name</label>
  <div class="col-10">
    <input class="form-control" name="nam" type="text"  id="example-date-input">
  </div>
</div>


	<div class="form-group row">
  <label for="example-date-input" class="col-2 col-form-label">Company Name</label>
  <div class="col-10">
    <input class="form-control" name="c_nam" type="text"  id="example-date-input">
  </div>
</div>


<div class="form-group row">
  <label for="example-email-input" class="col-2 col-form-label">Official Email ID</label>
  <div class="col-10">
    <input class="form-control" type="email" name="c_email" id="example-email-input">
  </div>
</div>


<div class="form-group row">
  <label for="example-email-input" class="col-2 col-form-label">Personal Email ID</label>
  <div class="col-10">
    <input class="form-control" type="email" name="p_email"  id="example-email-input">
  </div>
</div>














 <div class="form-group">
      <label class="control-label">I would like to contribute following amount every month (Please tick one)</label>
    </div>
    <div class="form-group">
      <div class="radio">
        <label class="radio-inline control-label">
          <input type="radio" id="amount_25" name="amount" value="500" checked="">
          500.00
        </label>
      </div>
    </div>
    <div class="form-group">
      <div class="radio">
        <label class="radio-inline control-label">
          <input type="radio" id="amount_50" name="amount" value="250">
          250.00
        </label>
      </div>
    </div>
    <div class="form-group">
      <div class="radio">
        <label class="radio-inline control-label">
          <input type="radio" id="amount_100" name="amount" value="200">
          200.00
        </label>
      </div>
    </div>
        <div class="form-group">
      <div class="radio">
        <label class="radio-inline control-label">
          <input type="radio" id="amount_100" name="amount" value="150">
          150.00
        </label>
      </div>
    </div>
    <div class="form-group">
      <div class="radio">
        <label class="radio-inline control-label">
          <input type="radio" id="amount_other" name="amount" value="Other:">
          Other:    <input placeholder="Amount" type="number" class="form-control" id="amount_actual" name="amount_actual"  data-rule-required="true" contenteditable="false">
        </label>
      </div>
    </div>
    <div class="form-group">
    	<div class="col-4">
    
      </div>
    </div>









	<div class="form-group row">
  <label for="example-date-input" class="col-2 col-form-label">Employee ID</label>
  <div class="col-4">
    <input class="form-control" name="emp_id" type="number" maxlength="6"  max ="999999" min="100000">
  </div>
</div>

	<div class="form-group row">
  <label for="example-date-input" class="col-2 col-form-label">Department Name</label>
  <div class="col-10">
    <input class="form-control" name="d_nam" type="text"  id="example-date-input">
  </div>
</div>



	<div class="form-group row">
  <label for="example-date-input" class="col-2 col-form-label">Location</label>
  <div class="col-10">
    <input class="form-control" name="loc" type="text"  id="example-date-input">
  </div>
</div>

<div class="form-group row">
  <label for="example-date-input" class="col-2 col-form-label">Mobile Number</label>
  <div class="col-4">
    <input class="form-control" name="phn" type="number" maxlength="10" max = "9999999999" min="1000000000">
  </div>
</div>

 <div class="form-group">
      <label class="control-label">Acknowledgement (Please tick one)</label>
    </div>
    <div class="form-group">
      <div class="radio">
        <label class="radio-inline control-label">
          <input type="radio" id="amount_25" name="ack" value=" Please don’t Acknowledge My donation publicily" checked="">
         Please don’t Acknowledge My donation publicily
        </label>
      </div>
    </div>
    <div class="form-group">
      <div class="radio">
        <label class="radio-inline control-label">
          <input type="radio" id="amount_50" name="ack" value="Please mail my tax Receipt ">
         Please mail my tax Receipt 
        </label>
      </div>
    </div>






    <button type="submit" name="ins" class="btn btn-primary">Submit</button>
<br>
<br>

<div class="form-group">
      <label class="control-label">                                                                                   CONTACT ADDRESS <br>
Plot No-13, Block A Om Vihar Phase v,
Behind Holi International School, Hastsal   Nawada Road, New Delhi– 110059 <br>
Phone No-011-25354225 
<br>alamb@bol. net.in,rustamalamb@gmail.com , clc.alamb2015@gmail.com ,
<br> Web: www.alamb.org

</label>
    </div>

    <?php

$con=mysqli_connect ("localhost","root","","alamb");
if (mysqli_connect_errno () )
 {
    echo "Connection is not established";
}







if (isset($_POST['ins'])) {
	
$dob	 =$_POST['dob']			;
$gender	 =$_POST['gender']			;
$nam	 =$_POST['nam']			;
$c_nam	 =$_POST['c_nam']			;
$c_email	 =$_POST['c_email']			;
$p_email	 =$_POST['p_email']			;
$amount	 =$_POST['amount']			;
$amount_actual	 =$_POST['amount_actual']			;
$emp_id	 =$_POST['emp_id']			;
$d_nam	 =$_POST['d_nam']			;
$loc	 =$_POST['loc']			;
$phn	 =$_POST['phn']			;
$ack	 =$_POST['ack']			;








   $insert_product = "INSERT INTO form_details (dob          ,
gender       ,
nam          ,
c_nam        ,
c_email      ,
p_email      ,
amount       ,
amount_actual,
emp_id       ,
d_nam        ,
loc          ,
phn          ,
ack          ) VALUES (

'$dob	        ',
'$gender	    ',
'$nam	        ',
'$c_nam	        ',
'$c_email	    ',
'$p_email	    ',
'$amount	    ',
'$amount_actual	',
'$emp_id	    ',
'$d_nam	        ',
'$loc	        ',
'$phn	        ',
'$ack	        '
) ";


 



  
if (mysqli_query( $con , $insert_product )) {
   

    echo "<script>alert('Record has been added')</script>";
    echo "<script>window.open('index.php','_self')</script>";
} else {
    echo "Error: " . $insert_product . "<br>" . mysqli_error($con);
}



}







?>

</form>

</div>
</div>
<br>
<br>
</body>
</html>



